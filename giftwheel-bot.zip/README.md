# GiftWheel Telegram Bot 🤖

Этот бот работает через библиотеку [pyTelegramBotAPI](https://github.com/eternnoir/pyTelegramBotAPI).  
Бот подключается к API https://giftsbattle.com и управляется через Telegram.

## 🚀 Запуск локально

```bash
export BOT_TOKEN="твой_токен"
export ADMIN_IDS="123456789,987654321"
python bot.py
```

## ☁️ Запуск на Render

1. Зайди на [https://render.com](https://render.com)
2. Создай **New Web Service**
3. Подключи свой GitHub-репозиторий
4. Укажи:
   - **Start Command:** `python bot.py`
   - **Environment Variables:**
     ```
     BOT_TOKEN=<твой_токен_из_BotFather>
     ADMIN_IDS=123456789
     ```
5. Нажми **Deploy** 🚀
